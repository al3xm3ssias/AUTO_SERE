"""
registro_scripts.py — registro dos scripts que usam as opções compartilhadas
=============================================================================
Cada script se registra UMA vez, dizendo:
  • quais recursos usa  (turma, situação matriculados/transferidos, CGM, teste, erros, debug);
  • como é executado    (`planejar`: transforma as opções num "plano" = função + argumentos).

A interface monta os campos a partir dos recursos declarados (um único componente de turma, um de
matriculados/transferidos, um de CGM...), e as rotas executam o plano. Para adicionar um script novo:

    registrar(Script(chave="meu_script", recursos=(RECURSO_TURMA, RECURSO_TESTE), planejar=_plano_meu_script))

e ele já ganha seleção de turma, modo de teste, prévia do que será processado e execução com log.
Scripts que ainda não foram migrados continuam no despacho antigo de src/web/api/rotas.py.

Aqui não há Flask nem rede; as funções pesadas (Playwright etc.) só são importadas dentro de `planejar`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from src.comum.opcoes_execucao import (RECURSO_CGM, RECURSO_DEBUG, RECURSO_ERROS, RECURSO_SITUACAO,
                                       RECURSO_TESTE, RECURSO_TURMA, Opcoes, argv_cli,
                                       filtrar_turmas_por_situacao, selecionar_alunos)

AJUDA_TESTE_PADRAO = ("Processa só o PRIMEIRO aluno da seleção, para você conferir antes de rodar tudo. "
                      "Atenção: não é simulação — esse aluno é processado de verdade.")


@dataclass(frozen=True)
class Plano:
    """O que executar: `tipo` diz como (gui = wrapper executar_*, coroutine, sync)."""
    tipo: str
    funcao: Callable
    kwargs: dict = field(default_factory=dict)
    log_inicial: str = ""


@dataclass(frozen=True)
class Script:
    chave: str
    recursos: tuple[str, ...]
    planejar: Callable[[Opcoes, dict, dict, dict], Plano]      # (opcoes, payload, turmas_json, contexto) → Plano
    cgm_obrigatorio: bool = False              # com o recurso CGM: True = exige CGMs; False = opcional (em branco vale turma/situação)
    confirmar: bool = False                    # pede confirmação com a prévia antes de executar (altera algo no SERE)
    aviso_confirmacao: str = ""
    ajuda_teste: str = AJUDA_TESTE_PADRAO
    ajuda_debug: str = ""
    extras: Callable[[], list[dict]] = lambda: []              # campos próprios do script (já com as opções resolvidas)
    validar_extras: Optional[Callable[[dict], None]] = None    # levanta ValueError com mensagem pronta
    turmas_de: Optional[Callable[[], list[str]]] = None        # fonte própria de nomes de turma (rematrícula)
    previa: Optional[Callable[[dict], str]] = None             # texto da prévia (ex.: "4 destinatários"); ValueError = aviso na tela

    @property
    def usa_turmas_json(self) -> bool:
        """Precisa de turmas.json (para turma/situação/CGM) — a menos que tenha fonte própria de turmas."""
        return self.turmas_de is None and bool(set(self.recursos) & {RECURSO_TURMA, RECURSO_SITUACAO, RECURSO_CGM})

    @property
    def tem_selecao_de_alunos(self) -> bool:
        return self.turmas_de is None and bool(set(self.recursos) & {RECURSO_TURMA, RECURSO_SITUACAO, RECURSO_CGM})


REGISTRO: dict[str, Script] = {}


def registrar(script: Script) -> Script:
    if script.chave in REGISTRO:
        raise ValueError(f"Script já registrado: {script.chave}")
    REGISTRO[script.chave] = script
    return script


def obter(chave: str) -> Optional[Script]:
    return REGISTRO.get(chave)


# ───────────────────────────── campos próprios (extras) ────────────────────────

def _opcoes_tipos_documento() -> list[dict]:
    from src.comum.sere_normalizacao import IDTIPO_PARA_SLOT
    return [{"valor": k, "texto": v} for k, v in sorted(IDTIPO_PARA_SLOT.items(), key=lambda kv: kv[1].lower())]


def _extras_tipo_documento() -> list[dict]:
    return [{"tipo": "select", "id": "campo-idtipo", "nome": "idtipo", "label": "Tipo de documento",
             "opcoes": _opcoes_tipos_documento()}]


def _validar_tipo_documento(payload: dict) -> None:
    from src.comum.sere_normalizacao import IDTIPO_PARA_SLOT
    if str(payload.get("idtipo") or "") not in IDTIPO_PARA_SLOT:
        raise ValueError("Escolha o tipo de documento.")


def _nome_do_tipo(payload: dict) -> tuple[str, str]:
    from src.comum.sere_normalizacao import IDTIPO_PARA_SLOT
    idtipo = str(payload["idtipo"])
    return idtipo, str(payload.get("nome_slot") or IDTIPO_PARA_SLOT[idtipo])


# ───────────────────────────── planos de cada script ───────────────────────────

# Flags guardadas na aba "Configuração" do analisa_sere que mandam mais do que uma seleção explícita.
_FLAGS_QUE_COMPETEM_COM_SELECAO = {"--todos", "--rapido", "--alunos", "--erros", "--turma", "--transferidos",
                                   "--matriculados", "--cgm"}


def _plano_analisa(o: Opcoes, p: dict, tj: dict, ctx: dict) -> Plano:
    from src.automacao.executar_analisa import executar_analisa
    flags = list(ctx.get("args_flags", []))
    if o.erros:
        # --erros e seleção não se combinam no script (cada um é um modo): reprocessar erros manda.
        argv = ["--erros"]
        flags = [f for f in flags if f not in _FLAGS_QUE_COMPETEM_COM_SELECAO]
    else:
        e_padrao = not o.turmas and not o.cgms and o.matriculados and not o.transferidos
        # Estado padrão da tela (todas as turmas, só matriculados) = não manda nada: assim as flags
        # guardadas na Configuração (ex.: --rapido) continuam valendo. Qualquer seleção explícita as substitui.
        if o.cgms:
            argv = ["--cgm", *o.cgms]            # CGMs informados mandam: turma/situação não entram
        else:
            argv = [] if e_padrao else argv_cli(o, {RECURSO_TURMA, RECURSO_SITUACAO})
        if argv:
            flags = [f for f in flags if f not in _FLAGS_QUE_COMPETEM_COM_SELECAO]
    args = [*flags, *argv]
    return Plano("gui", executar_analisa, {"args_extras": args},
                 "[OPÇÕES] " + (" ".join(args) if args else "nenhuma — modo completo"))


def _turmas_para(o: Opcoes, tj: dict) -> tuple[list[str], dict]:
    """(turmas a processar, dicionário de turmas já filtrado pela situação marcada)."""
    return (list(o.turmas) or list(tj)), filtrar_turmas_por_situacao(tj, matriculados=o.matriculados, transferidos=o.transferidos)


def _plano_validar(o, p, tj, ctx) -> Plano:
    from src.automacao.executar_validar import executar_validar
    alvo, filtradas = _turmas_para(o, tj)
    return Plano("gui", executar_validar, {
        "turmas_selecionadas": alvo, "turmas": filtradas, "modo_teste": o.modo_teste,
        "somente_transferidos": o.transferidos and not o.matriculados})


def _plano_documentos(o, p, tj, ctx) -> Plano:
    from src.automacao.executar_documento import executar_documento
    idtipo, nome = _nome_do_tipo(p)
    alvo, filtradas = _turmas_para(o, tj)
    return Plano("gui", executar_documento, {
        "idtipo": idtipo, "nome_slot": nome, "turmas_selecionadas": alvo, "turmas": filtradas,
        "modo_teste": o.modo_teste})


def _plano_limpeza(o, p, tj, ctx) -> Plano:
    from src.comum.executar_limpeza import executar_limpeza
    alvo, filtradas = _turmas_para(o, tj)
    return Plano("gui", executar_limpeza, {"turmas_selecionadas": alvo, "turmas": filtradas, "modo_teste": o.modo_teste})


def _plano_espec(o, p, tj, ctx) -> Plano:
    from src.automacao.executar_espec import executar_espec
    idtipo, nome = _nome_do_tipo(p)
    alvo, filtradas = _turmas_para(o, tj)
    return Plano("gui", executar_espec, {
        "idtipo_alvo": idtipo, "nome_slot": nome, "turmas_selecionadas": alvo, "turmas": filtradas,
        "modo_teste": o.modo_teste})


def _plano_aluno(o, p, tj, ctx) -> Plano:
    from src.automacao.executar_aluno import executar_aluno
    return Plano("gui", executar_aluno, {
        "modo_teste": o.modo_teste, "modo_erros": o.erros, "modo_faltando": bool(p.get("faltando", False)),
        "cgms": list(o.cgms)})


def _turmas_da_rematricula() -> list[str]:
    from src.automacao.rematricula import TURMAS_ALVO
    return list(TURMAS_ALVO)


def _plano_rematricula(o, p, tj, ctx) -> Plano:
    from src.automacao.rematricula import rematricular_via_login
    return Plano("coroutine", rematricular_via_login, {
        "modo_teste": o.modo_teste, "apenas_erros": o.erros, "turmas_alvo": list(o.turmas) or None})


def _plano_prematricula(o, p, tj, ctx) -> Plano:
    from src.automacao.pre_matricula import processo_completo_via_login
    return Plano("coroutine", processo_completo_via_login, {
        "analise": o.debug, "pular_pendentes": bool(p.get("pular_pendentes", False))})


def _plano_transferidos(o, p, tj, ctx) -> Plano:
    from src.automacao.executar_transferidos import executar_transferidos
    return Plano("gui", executar_transferidos, {"modo_teste": o.modo_teste})


def _plano_turmas(o, p, tj, ctx) -> Plano:
    from src.automacao.turmas import coletar_turmas_e_alunos_via_login
    return Plano("coroutine", coletar_turmas_e_alunos_via_login)


_OPCOES_MODO_FUNCIONARIOS = [
    {"valor": "completo", "texto": "Completo (lista + cadastro de cada um)",
     "ajuda": "Lê a lista e, para cada funcionário, consulta o cadastro pelo CPF: documentos, filiação e endereço. "
              "Mais lento. Grava funcionarios.json e funcionarios_completo.json. Se funcionarios.json já existe, "
              "usa essa lista (marque a opção abaixo para atualizá-la antes)."},
    {"valor": "basico", "texto": "Básico (só a lista)",
     "ajuda": "Lê a tela Consulta Funcionários/Docentes: nome, CPF, função, RG, mãe, e-mail, formação e turmas/"
              "disciplinas. Rápido. Grava funcionarios.json."},
]


def _extras_funcionarios() -> list[dict]:
    return [
        {"tipo": "select", "id": "campo-modo-func", "nome": "modo", "label": "Modo de coleta", "semVazio": True,
         "padrao": "completo", "opcoes": _OPCOES_MODO_FUNCIONARIOS},
        {"tipo": "caixa", "id": "campo-atualizar-lista", "nome": "atualizar_lista", "label": "Atualizar a lista antes",
         "descricao": "Refaz a lista de funcionários antes do cadastro completo, para pegar quem entrou ou saiu desde a "
                      "última coleta. Sem isso, o modo completo reaproveita a lista já salva.",
         "visivelSe": {"campo": "campo-modo-func", "valor": "completo"}},
    ]


def _plano_funcionarios(o, p, tj, ctx) -> Plano:
    modo = str(p.get("modo") or "completo").strip().lower()
    if modo not in ("basico", "completo"):
        raise ValueError(f"Modo '{modo}' desconhecido: use 'basico' ou 'completo'.")
    from src.automacao.servidores import coletar_funcionarios_automacao
    return Plano("coroutine", coletar_funcionarios_automacao,
                 {"modo": modo, "atualizar_lista": bool(p.get("atualizar_lista", False))})


_OPCOES_MODO_VINCULOS = [
    {"valor": "completo", "texto": "Completo (vincular + holerite de todos)",
     "ajuda": "Cruza os nomes do SERE com o RH, traz matrícula, cargo e data de admissão e confere no holerite de cada servidor "
              "se ele trabalha nesta escola. É o mais lento (uma consulta a cada 5 s); as consultas já feitas ficam em cache."},
    {"valor": "sere", "texto": "1. Consultar o SERE (só a lista)",
     "ajuda": "Refaz a lista de funcionários da escola no SERE (funcionarios.json) e para. Não consulta o RH da Prefeitura."},
    {"valor": "vincular", "texto": "2. Vincular com a matrícula da Prefeitura (rápido)",
     "ajuda": "Cruza os nomes do SERE com os servidores do RH e grava matrícula, nome do cargo e data de admissão de cada matrícula. "
              "Não consulta holerite. Quem não está entre os servidores vira terceirizado (ou estagiário)."},
    {"valor": "homonimos", "texto": "3. Verificar homônimos / duas matrículas",
     "ajuda": "Só para quem tem mais de uma matrícula com o mesmo nome (ou só para o nome/CPF informado): consulta o holerite de cada "
              "matrícula e vê qual está lotada nesta escola. Se só uma está, as outras são descartadas; se duas estão (dois concursos, "
              "ex.: professor 20h + 20h), ficam as duas, com cargo e admissão de cada uma. Os demais mantêm o resultado já gravado."},
]


def _extras_vinculos() -> list[dict]:
    com_rh = "vincular|homonimos|completo"
    return [
        {"tipo": "select", "id": "campo-modo-vinc", "nome": "modo", "label": "Modo de consulta", "semVazio": True,
         "padrao": "completo", "opcoes": _OPCOES_MODO_VINCULOS},
        {"tipo": "texto", "id": "campo-so-nome", "nome": "so_nome", "label": "Só este funcionário (nome ou CPF)",
         "placeholder": "em branco = todos com mais de uma matrícula", "visivelSe": {"campo": "campo-modo-vinc", "valor": "homonimos"}},
        {"tipo": "caixa", "id": "campo-pular-holerite", "nome": "pular_holerite", "label": "Não conferir no holerite (mais rápido)",
         "descricao": "Pula a comprovação: o holerite de cada servidor casado é consultado no RH (uma consulta a cada 5 s) "
                      "para confirmar que ele trabalha nesta escola. É o mesmo que o modo 2.",
         "visivelSe": {"campo": "campo-modo-vinc", "valor": "completo"}},
        {"tipo": "texto", "id": "campo-mes-holerite", "nome": "mes", "label": "Mês do holerite (MM-AAAA)",
         "placeholder": "em branco = mês anterior", "visivelSe": {"campo": "campo-modo-vinc", "valor": "homonimos|completo"}},
        {"tipo": "caixa", "id": "campo-atualizar-sere", "nome": "atualizar_sere", "label": "Atualizar antes a lista do SERE",
         "descricao": "Refaz a coleta básica de funcionários no SERE. Sem isso usa funcionarios.json (e só coleta se ele não existir).",
         "visivelSe": {"campo": "campo-modo-vinc", "valor": com_rh}},
        {"tipo": "caixa", "id": "campo-forcar-rh", "nome": "forcar_coleta", "label": "Baixar de novo as listas do RH",
         "descricao": "As listas do RH baixadas há menos de 24 h são reaproveitadas; marque para ignorar isso.",
         "visivelSe": {"campo": "campo-modo-vinc", "valor": com_rh}},
    ]


def _modo_vinculos(p: dict) -> str:
    """Modo escolhido; 'pular holerite' no modo completo (opção antiga) vale como o modo 'vincular'."""
    from src.automacao import funcionarios_vinculos as fv
    modo = fv.normalizar_modo(p.get("modo") or fv.MODO_COMPLETO)
    return fv.MODO_VINCULAR if modo == fv.MODO_COMPLETO and bool(p.get("pular_holerite", False)) else modo


def _validar_vinculos(p: dict) -> None:
    from src.automacao import funcionarios_vinculos as fv
    fv.validar_pedido(p.get("mes") or "", _modo_vinculos(p))


def _plano_vinculos(o, p, tj, ctx) -> Plano:
    from src.automacao import funcionarios_vinculos as fv
    modo = _modo_vinculos(p)
    mes = fv.validar_pedido(p.get("mes") or "", modo)
    return Plano("coroutine", fv.vincular_funcionarios_da_escola, {
        "modo": modo, "mes": mes, "forcar_coleta": bool(p.get("forcar_coleta", False)),
        "atualizar_sere": bool(p.get("atualizar_sere", False)), "so_nome": str(p.get("so_nome") or "").strip()})


_OPCOES_MODO_ALUNOS = [
    {"valor": "basico", "texto": "Básico (alunos.py)",
     "ajuda": "Lê a tela de consulta de cada aluno: documentos, filiação, endereço e contatos. Mais rápido. Grava alunos.json."},
    {"valor": "completo", "texto": "Completo (alunos_completo.py)",
     "ajuda": "Lê a tela de edição de cada aluno (cerca de 60 campos: deficiências, recursos de prova, perfil "
              "socioeconômico, atendimento especializado). Mais lento, salva aos poucos e registra erros. "
              "Grava alunos_completo.json. Precisa do turmas.json: rode antes a automação Turmas."},
]


def _extras_alunos() -> list[dict]:
    return [
        {"tipo": "select", "id": "campo-modo", "nome": "modo", "label": "Modo de coleta", "semVazio": True,
         "padrao": "basico", "opcoes": _OPCOES_MODO_ALUNOS},
        {"tipo": "caixa", "id": "campo-rapido", "nome": "rapido", "label": "Modo rápido",
         "descricao": "Pula os alunos já coletados nos últimos 2 meses e coleta só o que falta ou está desatualizado.",
         "visivelSe": {"campo": "campo-modo", "valor": "completo"}},
    ]


def _plano_alunos(o, p, tj, ctx) -> Plano:
    modo = str(p.get("modo") or "basico").strip().lower()
    if modo == "basico":
        from src.automacao.alunos import coletar_alunos_via_login
        return Plano("coroutine", coletar_alunos_via_login)
    if modo == "completo":
        if not tj:
            raise ValueError("O modo completo usa a lista de alunos de turmas.json, que ainda não existe ou está vazio: "
                             "execute primeiro a automação 'Turmas'.")
        from src.automacao.alunos_completo import coletar_cadastro_completo_via_login
        return Plano("coroutine", coletar_cadastro_completo_via_login, {"modo_rapido": bool(p.get("rapido", False))})
    raise ValueError(f"Modo '{modo}' desconhecido: use 'basico' ou 'completo'.")


def _plano_sus(o, p, tj, ctx) -> Plano:
    from src.automacao.sisreg import consultar_encaminhamentos_sisreg
    sel = selecionar_alunos(tj, turmas=o.turmas, matriculados=o.matriculados, transferidos=o.transferidos)
    if not sel.alunos:
        raise ValueError("Nenhum aluno na seleção: confira a turma e se Matriculados/Transferidos estão marcados.")
    return Plano("coroutine", consultar_encaminhamentos_sisreg, {"cgms": [a["CGM"] for a in sel.alunos]},
                 f"[OPÇÕES] consultando {sel.total} aluno(s); os demais mantêm o resultado anterior")


def _ler_raio(p: dict) -> float:
    """Raio em km (aceita vírgula). Vazio = padrão do projeto (RAIO_KM_PADRAO)."""
    from src.comum.cep_api import RAIO_KM_PADRAO
    bruto = str(p.get("raio_km") or "").strip().replace(",", ".")
    try:
        raio = float(bruto) if bruto else RAIO_KM_PADRAO
    except ValueError:
        raio = 0.0
    if not 0 < raio <= 100:
        raise ValueError("Raio inválido: informe um número de km (ex.: 2 ou 2,5).")
    return raio


def _plano_cep(o, p, tj, ctx) -> Plano:
    from src.comum.cep_api import executar_analise_distancia
    return Plano("sync", executar_analise_distancia, {"raio_km": _ler_raio(p)})


def _validar_tema(p: dict) -> None:
    if not str(p.get("tema") or "").strip():
        raise ValueError("Informe o tema do termo de ciência.")


def _plano_termos(o, p, tj, ctx) -> Plano:
    from src.automacao.termo_ciencia import gerar_termo
    from src.comum import escola
    # O nome da escola vem da configuração central (antes: o mais comum nos dados dos funcionários).
    return Plano("sync", gerar_termo, {"tema": str(p["tema"]).strip(), "nome_escola": escola.nome() or None})


def _plano_sync(modulo: str, funcao: str) -> Callable:
    """Plano de uma automação que só roda uma função sem parâmetros."""
    def planejar(o, p, tj, ctx) -> Plano:
        import importlib
        return Plano("sync", getattr(importlib.import_module(modulo), funcao))
    return planejar


# ───────────────────────────── registro ────────────────────────────────────────

def _ler_limite_mb(payload: dict) -> float:
    """Limite acima do qual comprime (MB). Em branco = limite do SERE; 0 = todos os arquivos."""
    from src.comum.compressao import LIMITE_SERE_MB
    bruto = str(payload.get("limite_mb") or "").strip().replace(",", ".")
    if not bruto:
        return LIMITE_SERE_MB
    try:
        valor = float(bruto)
    except ValueError:
        raise ValueError(f"Tamanho inválido: '{payload.get('limite_mb')}'. Digite um número em MB (ex.: 1,5) ou 0 para todos.") from None
    if not 0 <= valor <= 500:
        raise ValueError("O tamanho deve ficar entre 0 e 500 MB (0 = comprimir todos os arquivos).")
    return valor


def _plano_comprimir(o, payload, turmas_json, ctx):
    from src.automacao.comprimir import executar_comprimir
    return Plano("sync", executar_comprimir, {
        "turmas": list(o.turmas),                       # vazio = a pasta inteira, com TRANSFERENCIAS
        "limite_mb": _ler_limite_mb(payload),
        "guardar_originais": not payload.get("descartar_originais"),
        "somente_calcular": bool(payload.get("somente_calcular")),
        "modo_teste": o.modo_teste,
    })


def _anos_escolhidos(p: dict) -> tuple[str, str]:
    """(ano base, ano comparado), conferidos contra as pastas dados/<ano>/turmas.json que existem."""
    from src.relatorios.comparar_anos import anos_com_turmas
    anos = anos_com_turmas()
    if len(anos) < 2:
        achado = f"só encontrei o turmas.json de {anos[0]}" if anos else "não encontrei nenhum turmas.json"
        raise ValueError(
            f"Para comparar preciso do turmas.json de dois anos: {achado}. Coloque o arquivo do outro ano em "
            "dados/<ano>/turmas.json (ex.: dados/2025/turmas.json, copiado do ano passado) e rode de novo.")
    base, comparado = str(p.get("ano_base") or "").strip(), str(p.get("ano_comparado") or "").strip()
    if not base or not comparado:
        raise ValueError("Escolha o ano base e o ano comparado.")
    for ano in (base, comparado):
        if ano not in anos:
            raise ValueError(f"Não existe dados/{ano}/turmas.json.")
    if base >= comparado:
        raise ValueError("O ano base deve ser anterior ao ano comparado (ex.: base 2025, comparado 2026).")
    return base, comparado


def _extras_compara_anos() -> list[dict]:
    from src.comum import paths
    from src.relatorios.comparar_anos import anos_com_turmas
    anos = anos_com_turmas()
    opcoes = [{"valor": a, "texto": a} for a in anos]
    atual = paths.ano_atual()
    comparado = atual if atual in anos else (anos[-1] if anos else "")
    anteriores = [a for a in anos if a < comparado]
    base = anteriores[-1] if anteriores else (anos[0] if anos else "")
    return [
        {"tipo": "select", "id": "campo-ano-base", "nome": "ano_base", "label": "Ano base (o mais antigo)",
         "semVazio": True, "padrao": base, "opcoes": opcoes},
        {"tipo": "select", "id": "campo-ano-comparado", "nome": "ano_comparado", "label": "Ano comparado (o mais novo)",
         "semVazio": True, "padrao": comparado, "opcoes": opcoes},
    ]


def _plano_compara_anos(o, p, tj, ctx):
    from src.relatorios.comparar_anos import executar_compara_anos
    base, comparado = _anos_escolhidos(p)
    return Plano("sync", executar_compara_anos, {"ano_base": base, "ano_comparado": comparado})


def _extras_parecer_rco() -> list[dict]:
    from src.automacao.parecer_rco import BIMESTRES
    return [
        {"tipo": "select", "id": "campo-bimestre", "nome": "bimestre", "label": "Bimestre",
         "opcoes": [{"valor": k, "texto": v} for k, v in BIMESTRES.items()]},
        {"tipo": "caixa", "id": "campo-mostrar-navegador", "nome": "mostrar_navegador", "label": "Mostrar o navegador",
         "descricao": "Abre a janela do RCO enquanto trabalha. Útil se algo falhar; por padrão ela fica escondida."},
    ]


def _validar_parecer_rco(p: dict) -> None:
    from src.automacao import parecer_rco
    parecer_rco.validar_pedido(p.get("bimestre"))


def _plano_parecer_rco(o, p, tj, ctx) -> Plano:
    from src.automacao.parecer_rco import CHAVE, gerar_pareceres_infantil_via_login
    return Plano("coroutine", gerar_pareceres_infantil_via_login, {
        "bimestre": p.get("bimestre"), "modo_teste": o.modo_teste,
        "mostrar_navegador": bool(p.get("mostrar_navegador", False)), "chave": CHAVE})


def _plano_parecer_fund(o, p, tj, ctx) -> Plano:
    from src.automacao import parecer_fund as pf
    # Nada escolhido = todas as turmas que têm modelo; turma escolhida sem modelo = erro com a lista delas.
    turmas = pf.conferir_modelos(list(o.turmas) or list(tj), explicitas=bool(o.turmas))
    pf.nome_da_escola_para_o_modelo()                                   # falha já aqui se a escola não foi informada
    sel = selecionar_alunos(tj, turmas=turmas, matriculados=o.matriculados, transferidos=o.transferidos, cgms=o.cgms)
    if not sel.alunos:
        raise ValueError("Nenhum aluno na seleção: confira a turma e se Matriculados/Transferidos estão marcados.")
    alunos = pf.montar_alunos(tj, sel.alunos)
    if o.modo_teste:
        alunos = alunos[:1]
    return Plano("sync", pf.gerar_pareceres_fundamental, {"alunos": alunos, "substituir": bool(p.get("substituir", False))},
                 f"[OPÇÕES] {len(alunos)} parecer(es) em {len({a['turma'] for a in alunos})} turma(s)")


def _args_avisos(p: dict) -> dict:
    return {"publico": p.get("publico"), "canal": p.get("canal") or "email", "modo": p.get("modo") or "simular",
            "assunto": p.get("assunto"), "mensagem": p.get("mensagem"),
            "tipo_escola": p.get("tipo_escola") or "todas", "filtro_nome": p.get("filtro_nome") or "",
            "situacao_pais": p.get("situacao_pais") or "matriculados", "email_teste": p.get("email_teste") or ""}


def _extras_avisos() -> list[dict]:
    from src.automacao import avisos as av
    so = lambda campo, valor: {"campo": campo, "valor": valor}
    marcadores = {
        "escolas": "Marcadores no assunto e na mensagem: " + ", ".join("$" + m for m in av.marcadores_validos("escolas")),
        "pais": "Marcadores no assunto e na mensagem: " + ", ".join("$" + m for m in av.marcadores_validos("pais")),
    }
    return [
        {"tipo": "select", "id": "campo-publico", "nome": "publico", "label": "Para quem",
         "opcoes": [{"valor": k, "texto": v, "ajuda": marcadores[k]} for k, v in av.PUBLICOS.items()]},
        {"tipo": "select", "id": "campo-canal", "nome": "canal", "label": "Canal", "semVazio": True, "padrao": "email",
         "opcoes": [{"valor": k, "texto": v} for k, v in av.CANAIS.items()]},
        {"tipo": "select", "id": "campo-modo-aviso", "nome": "modo", "label": "Modo", "semVazio": True, "padrao": "simular",
         "opcoes": [
             {"valor": "simular", "texto": av.MODOS["simular"],
              "ajuda": "Lista quem receberia e mostra a prévia da mensagem. Não envia nada."},
             {"valor": "teste", "texto": av.MODOS["teste"],
              "ajuda": "Envia UM e-mail de verdade, só para o e-mail de teste. Para escolas, vai para a escola fictícia "
                       "ESCOLA MUNICIPAL TESTE DA SILVA. Os destinatários reais não recebem nada."}]},
        {"tipo": "select", "id": "campo-tipo-escola", "nome": "tipo_escola", "label": "Quais unidades", "semVazio": True,
         "padrao": "todas", "opcoes": [{"valor": k, "texto": v} for k, v in av.TIPOS_ESCOLA.items()],
         "visivelSe": so("campo-publico", "escolas")},
        {"tipo": "texto", "id": "campo-filtro-nome", "nome": "filtro_nome", "label": "Só unidades cujo nome contém (opcional)",
         "placeholder": "ex.: Rural", "visivelSe": so("campo-publico", "escolas")},
        {"tipo": "select", "id": "campo-situacao-pais", "nome": "situacao_pais", "label": "Quais alunos novos",
         "semVazio": True, "padrao": "matriculados", "opcoes": [{"valor": k, "texto": v} for k, v in av.SITUACOES_PAIS.items()],
         "visivelSe": so("campo-publico", "pais")},
        {"tipo": "texto", "id": "campo-assunto", "nome": "assunto", "label": "Assunto",
         "placeholder": "ex.: Comunicado oficial - $ESCOLA"},
        {"tipo": "texto", "multilinha": True, "id": "campo-mensagem", "nome": "mensagem", "label": "Mensagem",
         "placeholder": "Escreva o comunicado. Use os marcadores acima para personalizar."},
        {"tipo": "texto", "id": "campo-email-teste", "nome": "email_teste", "label": "E-mail de teste (opcional)",
         "placeholder": "em branco: escolas → a escola fictícia; pais → o e-mail do remetente",
         "visivelSe": so("campo-modo-aviso", "teste")},
    ]


def _previa_avisos(p: dict) -> str:
    """Quantos destinatários o comunicado alcançaria com as escolhas atuais (não exige o texto pronto)."""
    from src.automacao import avisos as av
    if p.get("publico") not in av.PUBLICOS:
        return ""
    if av.teste_com_escola_ficticia(p["publico"], p.get("modo") or "simular"):
        email = (p.get("email_teste") or "").strip() or av.ESCOLA_TESTE["email"]
        texto = f"Teste: 1 e-mail para a escola fictícia {av.ESCOLA_TESTE['nome']} <{email}>"
        try:
            n = len(av.reunir_destinatarios("escolas", p.get("tipo_escola") or "todas", p.get("filtro_nome") or "")["destinatarios"])
            texto += f" (o comunicado real iria para {n} e-mail(s) de escolas e CMEIs)"
        except ValueError:
            pass                                # sem a lista real o teste funciona do mesmo jeito
        return texto + "."
    r = av.reunir_destinatarios(p["publico"], p.get("tipo_escola") or "todas", p.get("filtro_nome") or "",
                                p.get("situacao_pais") or "matriculados")
    n = len(r["destinatarios"])
    if p["publico"] == "pais":
        texto = f"{n} responsável(is) por e-mail, de {r['alunos']} aluno(s) novo(s)"
    else:
        texto = f"{n} e-mail(s) de escolas e CMEIs"
    if r["sem_email"]:
        texto += f"; {len(r['sem_email'])} sem e-mail válido ficariam de fora"
    return texto + ". O envio real ainda não está liberado: use Simular ou Teste."


def _validar_avisos(p: dict) -> None:
    from src.automacao import avisos as av
    a = av.validar_pedido(**_args_avisos(p))
    if av.teste_com_escola_ficticia(a["publico"], a["modo"]):
        return                                  # o teste com a escola fictícia não depende da lista real
    av.reunir_destinatarios(a["publico"], a["tipo_escola"], a["filtro_nome"], a["situacao_pais"])


def _plano_avisos(o, p, tj, ctx) -> Plano:
    from src.automacao import avisos as av
    a = _args_avisos(p)
    return Plano("sync", av.executar_avisos, a, f"[AVISOS] público={a['publico']} | canal={a['canal']} | modo={a['modo']}")


_T, _S, _C, _TE, _E, _D = RECURSO_TURMA, RECURSO_SITUACAO, RECURSO_CGM, RECURSO_TESTE, RECURSO_ERROS, RECURSO_DEBUG

registrar(Script("analisa_sere", (_T, _S, _C, _E), _plano_analisa))

registrar(Script("validar", (_T, _S, _TE), _plano_validar, confirmar=True,
                 aviso_confirmacao="Valida (clica em \"validar\") os documentos pendentes desses alunos no SERE."))

registrar(Script("documentos", (_T, _S, _TE), _plano_documentos, confirmar=True,
                 aviso_confirmacao="REMOVE do SERE o tipo de documento escolhido desses alunos.",
                 extras=_extras_tipo_documento, validar_extras=_validar_tipo_documento))

registrar(Script("limpeza", (_T, _S, _TE), _plano_limpeza, confirmar=True,
                 aviso_confirmacao="REMOVE TODOS os arquivos desses alunos no SERE. Não dá para desfazer."))

registrar(Script("espec", (_T, _S, _TE), _plano_espec, confirmar=True,
                 aviso_confirmacao="Envia ao SERE o tipo de documento escolhido (da pasta de digitalização) para esses alunos.",
                 extras=_extras_tipo_documento, validar_extras=_validar_tipo_documento))

registrar(Script("aluno", (_C, _TE, _E), _plano_aluno, cgm_obrigatorio=True, confirmar=True,
                 aviso_confirmacao="Envia ao SERE os documentos da pasta de digitalização só destes alunos.",
                 extras=lambda: [{"tipo": "caixa", "id": "campo-faltando", "nome": "faltando",
                                  "label": "Só quem ainda tem documento pendente",
                                  "descricao": "Pula os alunos que já estão com todos os documentos no SERE."}]))

registrar(Script("rematricula", (_T, _TE, _E), _plano_rematricula, confirmar=True, turmas_de=_turmas_da_rematricula,
                 aviso_confirmacao="Faz a rematrícula desses alunos no SERE.",
                 ajuda_teste="Faz a rematrícula de só 1 aluno por turma, para você conferir antes de rodar tudo. "
                             "Atenção: não é simulação — esses alunos são rematriculados de verdade."))

registrar(Script("prematricula_completa", (_D,), _plano_prematricula,
                 ajuda_debug="Modo de análise: salva uma captura de tela de cada etapa em dados/<ano>/screenshots, "
                             "para descobrir o que mudou no site se algo falhar.",
                 extras=lambda: [{"tipo": "caixa", "id": "campo-pular", "nome": "pular_pendentes",
                                  "label": "Pular a verificação de pendentes (Etapa 4)",
                                  "descricao": "Mais rápido; não consulta de novo quem ainda está pendente."}]))

registrar(Script("transferidos", (_TE,), _plano_transferidos, confirmar=True,
                 aviso_confirmacao="Processa os alunos de transferidos.json no SERE.",
                 ajuda_teste="Processa só a primeira tarefa. Atenção: não é simulação — ela é executada de verdade."))


registrar(Script("parecer_rco", (_TE,), _plano_parecer_rco, validar_extras=_validar_parecer_rco,
                 extras=_extras_parecer_rco,
                 ajuda_teste="Baixa só o parecer do primeiro aluno do Infantil IV/V, para você conferir o login, o código "
                             "de verificação e a pasta antes de rodar todos."))

registrar(Script("parecer_fund", (_T, _S, _C, _TE), _plano_parecer_fund,
                 ajuda_teste="Gera só o parecer do primeiro aluno da seleção, para você conferir o resultado antes de gerar todos.",
                 extras=lambda: [{"tipo": "caixa", "id": "campo-substituir", "nome": "substituir",
                                  "label": "Substituir pareceres que já existem",
                                  "descricao": "Por padrão um parecer já gerado é mantido (o professor pode já ter preenchido). "
                                               "Marque só para refazer do zero."}]))

registrar(Script("avisos", (), _plano_avisos, validar_extras=_validar_avisos, extras=_extras_avisos,
                 previa=_previa_avisos))

# ── coletas e relatórios (sem opções compartilhadas, ou só as próprias) ──
registrar(Script("turmas", (), _plano_turmas))
registrar(Script("alunos", (), _plano_alunos, extras=_extras_alunos))
registrar(Script("funcionarios", (), _plano_funcionarios, extras=_extras_funcionarios))
registrar(Script("vinculos", (), _plano_vinculos, validar_extras=_validar_vinculos, extras=_extras_vinculos))
registrar(Script("sus", (_T, _S), _plano_sus))
registrar(Script("cep", (), _plano_cep, validar_extras=_ler_raio,
                 extras=lambda: [{"tipo": "texto", "id": "campo-raio", "nome": "raio_km", "label": "Raio de atendimento (km)",
                                  "placeholder": "2 (padrão do sistema)"}]))
registrar(Script("termos", (), _plano_termos, validar_extras=_validar_tema,
                 extras=lambda: [
                     {"tipo": "texto", "id": "campo-tema", "nome": "tema", "label": "Tema do termo de ciência",
                      "placeholder": "Ex.: Uso de imagem"},
                     {"tipo": "pasta", "label": "Pasta com o modelo do termo (o termo gerado é salvo nela)", "destino": "modelos"},
                 ]))
registrar(Script("comprimir", (_T, _TE), _plano_comprimir, confirmar=True, validar_extras=_ler_limite_mb,
                 aviso_confirmacao="SUBSTITUI os PDFs e imagens maiores que o limite por versões comprimidas (qualidade menor; "
                                   "mesmo nome e mesma data). Os originais ficam em dados/<ano>/ORIGINAIS_ANTES_DA_COMPRESSAO, "
                                   "a menos que você marque para não guardar. Com \"Só calcular\" nada é alterado.",
                 ajuda_teste="Comprime só o primeiro arquivo que passar do limite, para você conferir a qualidade antes de rodar tudo. "
                             "Atenção: não é simulação — esse arquivo é substituído de verdade (o original fica guardado).",
                 extras=lambda: [
                     {"tipo": "texto", "id": "campo-limite", "nome": "limite_mb", "label": "Comprimir arquivos maiores que (MB)",
                      "placeholder": "1,5 (limite do SERE) — 0 comprime todos"},
                     {"tipo": "caixa", "id": "campo-calcular", "nome": "somente_calcular", "label": "Só calcular quanto vai economizar",
                      "descricao": "Não altera nenhum arquivo: mostra no log quanto cada um encolheria. Bom para ver antes de comprimir."},
                     {"tipo": "caixa", "id": "campo-descartar", "nome": "descartar_originais", "label": "Não guardar cópia dos originais",
                      "descricao": "Por padrão cada original é guardado antes de ser substituído. Marque só se estiver sem espaço em disco."},
                 ]))

registrar(Script("compara_anos", (), _plano_compara_anos, validar_extras=_anos_escolhidos, extras=_extras_compara_anos))
registrar(Script("gerar_pastas", (), _plano_sync("src.automacao.gerar_pastas", "main")))
registrar(Script("analisa_pasta", (), _plano_sync("src.relatorios.analisa_documentos_pc", "main"),
                 extras=lambda: [{"tipo": "pasta", "label": "Pasta de digitalização a ser analisada", "destino": "digitalizacao"}]))
registrar(Script("mapear_pastas", (), _plano_sync("src.relatorios.mapear_pastas_alunos", "main"),
                 extras=lambda: [{"tipo": "pasta", "label": "Pasta raiz dos alunos", "destino": "digitalizacao"}]))
registrar(Script("cruzamento", (), _plano_sync("src.relatorios.cruzar_documentos", "main")))
registrar(Script("mascara", (), _plano_sync("src.relatorios.mascarar", "main")))
registrar(Script("coleta_emails", (), _plano_sync("src.automacao.coleta_emails", "coletar_escolas_municipais")))
registrar(Script("backup", (), _plano_sync("src.comum.backup", "executar_backup")))
