"""Configuração comum dos testes: a raiz do projeto entra no caminho de importação,
para que `from src...` funcione sem precisar de PYTHONPATH."""
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))
